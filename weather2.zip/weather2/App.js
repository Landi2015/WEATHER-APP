import React, {useState}  from 'react';
import { Text, View, StyleSheet,ImageBackground } from 'react-native';
import Constants from 'expo-constants';
import Weather from './components/Weather'
import WeatherForm from './components/WeatherForm';

const API_KEY = 'e819cbc2e47e0805c33dce210c1aedd5';

const image = { uri: "https://i.pinimg.com/originals/eb/2a/2e/eb2a2eff2f5d96d129ff6433f7701d38.jpg" };


export default function App() {
   const [weatherdata, setData] = useState({
     name:"",
     main:{
       temp_min:""
     },
     weather:[{
       discription:"",
       icon:""
     }],
     
   })
   
   
  const getWeather = (cityname) => {
    let searchCity = 'Kimberley';
    const APIURL = `https://api.openweathermap.org/data/2.5/weather?units=metric&q=${cityname}&exclude=hourly,minutely&units=metric&appid=${API_KEY}`;
    fetch(APIURL)
      .then((response) => response.json()).then((data)=>{
       
        setData(data)


      })

  }
    
  return (
  
    <View style={styles.container}>
      <ImageBackground source={image} style={styles.image}>
      <WeatherForm getWeather={getWeather} />
      <Weather data ={weatherdata}/>
      </ImageBackground>
    </View>
  )
}

const styles = StyleSheet.create({
    container: {
    flex: 1,
  },
  image: {
    flex: 1,
    justifyContent: "center"
  },
 
});
