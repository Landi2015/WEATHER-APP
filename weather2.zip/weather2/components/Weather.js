import React, { useState } from 'react';
import { Text, View, StyleSheet, Image } from 'react-native';

function Weather(props) {
  const [img, setimg] = useState(
    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTEPdm9-Q2HvjRNj8MEB-5eK99OAv6CMd9BdQ&usqp=CAU'
  );

  console.log(props.data);

  let { name } = props.data;
  let { main } = props.data;
  let { weather } = props.data;
  let { icon } = 'http://openweathermap.org/img/wn/10d@2x.png';

  const im = 'http://openweathermap.org/img/wn/10d@2x.png';

  return (
    <View style={styles.texts}>
      <Text style={styles.city}>{name} </Text>
      <Text style={styles.temp}>{main.temp_min}</Text>
      <Text style={styles.description}>{weather[0].description} </Text>
      <Text>{weather[0].icon} </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  texts: {
    textAlign: 'centre',
    color: 'white',
    paddingLeft: 40,
    paddingTop: 25,
  },
  city: {
    fontSize: 50,
    color: 'white',
    paddingLeft: 45,
  },
  temp: {
    fontSize: 30,
    color: 'white',
    paddingLeft: 45,
  },
  description: {
    fontSize: 40,
    color: 'white',
    paddingLeft: 40,
  },
});

export default Weather;
