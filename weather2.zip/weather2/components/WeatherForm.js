import React , {useState} from 'react';
import { Text, View, StyleSheet, TextInput,TouchableOpacity } from 'react-native';

function WeatherForm(props) {

  const [cityname, setcityname] =useState('')


  const getWeather =()=>{
    props.getWeather(cityname);

  }
  return (
    <View>
      <TextInput  style={styles.textfield} placeholder="City name" onChangeText={(city)=>setcityname(city)}/>  

      <TouchableOpacity style={styles.btn} onPress={getWeather}> 
      <Text style={styles.text}> GET WEATHER </Text>
       </TouchableOpacity>
    </View>
  );
}



const styles = StyleSheet.create({

  textfield:{
    borderWidth:2,
    borderColor:'white',
    width:250,
    height:50,
    marginTop:10,
    marginLeft:50,
    borderRadius:10,
    paddingLeft:10,
    color:'white',
   
  } ,
  btn:{
    backgroundColor:'#3c3c44' ,
    width:200,
    height:50,
    marginTop:10,
    marginLeft:70,
    borderRadius:15,

  },
text:{
  color:'white',
  paddingTop:15,
  paddingLeft:50,
},

})
export default WeatherForm;
